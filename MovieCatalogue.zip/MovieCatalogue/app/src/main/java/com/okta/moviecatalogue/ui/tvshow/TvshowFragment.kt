package com.okta.moviecatalogue.ui.tvshow


import android.content.Intent
import android.content.res.TypedArray
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ListView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.okta.moviecatalogue.R
import com.okta.moviecatalogue.model.Movie
import com.okta.moviecatalogue.ui.detail.DetailActivity
import com.okta.moviecatalogue.ui.movie.RVMovieAdapter
import kotlinx.android.synthetic.main.fragment_tvshow.*

/**
 * A simple [Fragment] subclass.
 */
class TvshowFragment : Fragment() {

    private lateinit var adapter: RVTvShowAdapter
    private lateinit var dataName: Array<String>
    private lateinit var dataDescription: Array<String>
    private lateinit var dataPhoto: TypedArray
    private var movies = arrayListOf<Movie>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tvshow, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView: RecyclerView = activity!!.findViewById(R.id.rv_list_tv)
        rv_list_tv.setHasFixedSize(true)


        prepare()

        addItem()
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = RVTvShowAdapter(movies)
        recyclerView.adapter = adapter

        adapter.setOnItemClickCallback(object : RVTvShowAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Movie) {
                val moveWithDataIntent = Intent(context, DetailActivity::class.java)
                moveWithDataIntent.putExtra(DetailActivity.EXTRA_MOVIE, data)
                startActivity(moveWithDataIntent)
            }

        })
    }

    private fun prepare() {
        dataName = resources.getStringArray(R.array.data_name)
        dataDescription = resources.getStringArray(R.array.data_description)
        dataPhoto = resources.obtainTypedArray(R.array.data_photo)
    }

    private fun addItem() {
        for (position in dataName.indices) {
            val movie = Movie(
                dataPhoto.getResourceId(position, -1),
                dataName[position],
                dataDescription[position]
            )
            movies.add(movie)
        }
    }

}
