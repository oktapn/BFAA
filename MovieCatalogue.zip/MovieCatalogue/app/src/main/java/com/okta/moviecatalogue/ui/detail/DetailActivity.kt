package com.okta.moviecatalogue.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.okta.moviecatalogue.model.Movie
import com.okta.moviecatalogue.R
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        if (intent != null) {
            val person = intent.getParcelableExtra(EXTRA_MOVIE) as Movie
            txt_description_dtl.text = person.description
            txt_name_dtl.text = person.name
            Glide.with(this@DetailActivity).load(person.photo).into(img_photo_dtl)
        }
    }
}
